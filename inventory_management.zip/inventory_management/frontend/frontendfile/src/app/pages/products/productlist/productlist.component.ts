
import {AfterViewInit,OnInit, Component, ViewChild} from '@angular/core';
import {MatPaginator, MatPaginatorModule} from '@angular/material/paginator';
import {MatTableDataSource, MatTableModule} from '@angular/material/table';
import { ApiService } from '../../../services/api.service';
import { MatDialog } from '@angular/material/dialog';
import { AddproductComponent } from '../addproduct/addproduct.component';
import { UpdateproductComponent } from '../updateproduct/updateproduct.component';

export interface Product {
  id: number;
  name: string;
  product_code: string;
  quantity: number;
  price: string;
  description: string;
  created_at: string;
  updated_at: string;
  created_by: number;
}

@Component({
  selector: 'app-productlist',
  templateUrl: './productlist.component.html',
  styleUrl: './productlist.component.css'
})
export class ProductlistComponent {
 displayedColumns: string[] = ['position', 'name','productcode', 'quantity', 'price','createdby','updatedby','actions'];
  dataSource = new MatTableDataSource<Product>();
 userRole: string | null = null;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  constructor(private productService: ApiService,private dialog: MatDialog) {}
  
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }
    ngOnInit(): void {
       this.userRole = localStorage.getItem('userRole');
this.getprod();
    }
    getprod(){
    this.productService.getproducts().subscribe((result) => {
      console.log("result",result);
      
      this.dataSource.data = result;
    });
    }
     get isAdmin(): boolean {
    return this.userRole === 'admin';
  }
openAddDialog() {
  const dialogRef = this.dialog.open(AddproductComponent, {
    
   width: '500px',

    disableClose: true,  
    backdropClass: 'custom-backdrop', 
    panelClass: 'custom-dialog-container' 
  });
  dialogRef.afterClosed().subscribe(result => {
    if (result === 'success') {
      // Show confirmation message
      alert('Product added successfully!');
      
      this.getprod(); // or any method to reload data
    }
  });
  
}
editAddDialog(product: any) {
  const dialogRef = this.dialog.open(UpdateproductComponent, {
    
   width: '500px',
data: product,
    disableClose: true,  
    backdropClass: 'custom-backdrop', 
    panelClass: 'custom-dialog-container' 
  });
  dialogRef.afterClosed().subscribe(result => {
    if (result === 'success') {
      // Show confirmation message
      alert('Product updated successfully!');
      
      this.getprod(); // or any method to reload data
    }
  });
  
}
deleteProduct(id: number) {
  if (confirm('Are you sure you want to delete this product?')) {
    this.productService.deleteproduct(id).subscribe({
      next: (res:any) => {
        alert('Product deleted successfully!');
        this.getprod(); 
      },
      error: (err:any) => {
        console.error('Error deleting product:', err);
        alert('Failed to delete product.');
      }
    });
  }
}

}



