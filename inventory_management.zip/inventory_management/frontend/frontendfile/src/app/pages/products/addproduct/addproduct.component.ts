import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { ApiService } from '../../../services/api.service';
import { Validators } from '@angular/forms';
@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrl: './addproduct.component.css'
})
export class AddproductComponent {
productForm: FormGroup;

  constructor(
    private productService: ApiService,
    private fb: FormBuilder,
    private dialogRef: MatDialogRef<AddproductComponent>
  ) {
    this.productForm = this.fb.group({
     name: ['', Validators.required],
  product_code: ['', Validators.required],
  quantity: ['', [Validators.required, Validators.min(1)]],
  price: ['', [Validators.required, Validators.min(0.01)]],
  description: ['']
    });
  }

  submit() {
    if (this.productForm.valid) {
      this.productService.postproducts(this.productForm.value).subscribe({
            next: (res) => {
        console.log('Product added successfully', res);
        this.dialogRef.close('success');  // close dialog and send result
      },
      error: (err) => {
        console.error('Error adding product', err);
      }
      });
  }
  }
}
