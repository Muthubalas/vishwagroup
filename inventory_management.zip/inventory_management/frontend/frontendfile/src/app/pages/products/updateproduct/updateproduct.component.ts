import { Component,Inject} from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ApiService } from '../../../services/api.service';
import { Validators } from '@angular/forms';
@Component({
  selector: 'app-updateproduct',
  templateUrl: './updateproduct.component.html',
  styleUrl: './updateproduct.component.css'
})
export class UpdateproductComponent {
  productForm!: FormGroup;

  constructor(
    private productService: ApiService,
    private fb: FormBuilder,
    private dialogRef: MatDialogRef<UpdateproductComponent>,
     @Inject(MAT_DIALOG_DATA) public data: any
    
  ) {
   
  }
    ngOnInit(): void {
    this.productForm = this.fb.group({
    name: [this.data.name, Validators.required],
    product_code: [this.data.product_code, Validators.required],
    quantity: [this.data.quantity, [Validators.required, Validators.min(1)]],
    price: [this.data.price, [Validators.required, Validators.min(0.01)]],
    description: [this.data.description]
    });
  }

  submit() {
    if (this.productForm.valid) {
      this.productService.updateproduct(this.data.id,this.productForm.value).subscribe({
   
        
            next: (res) => {
                   console.log("     console.log(this.data.id);",this.data.id);
        console.log('Product added successfully', res);
        this.dialogRef.close('success');  // close dialog and send result
      },
      error: (err) => {
        console.error('Error update product', err);
      }
      });
  }
  }
}
