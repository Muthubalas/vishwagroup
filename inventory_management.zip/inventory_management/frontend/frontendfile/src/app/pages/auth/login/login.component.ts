import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { ApiService } from '../../../services/api.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

 loginForm: FormGroup;
  hidePassword: boolean = true;
  errorMsg: string = '';

  constructor(private fb: FormBuilder, private http: HttpClient,private api: ApiService,private router: Router) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
    });
  }
 togglePassword() {
    this.hidePassword = !this.hidePassword;
  }

  get email() {
    return this.loginForm.get('email')!;
  }

  get password() {
    return this.loginForm.get('password')!;
  }

  onSubmit() {
    if (this.loginForm.valid) {
      const formData = this.loginForm.value;
      console.log('Sending login data:', formData);

   this.api.loginpost('', formData).subscribe({
        next: (response) => {
           localStorage.setItem('token', response.token);
           localStorage.setItem('userRole', response.role);
          console.log('Login successful:', response);
          this.router.navigate(['/products']);
          // Save token or navigate
        },
        error: (err) => {
          console.error('Login failed:', err);
        }
      });
    }
  }
}
